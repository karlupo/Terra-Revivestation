Config = {}
Config.x = -463.72
Config.y = -339.04
Config.z = 34.5
Config.Price = 10000
Config.ReviveRange = 6
Config.AccessRange = 1