Locales['de'] = {
    ['sendername'] = 'Bankberater',
    ['sendercompany'] = 'Los Santos Zentralbank',
    ['bought_msg'] = 'Sie haben einen Betrag von %s$ an das Medical Department überwiesen. Schönen Tag noch!',
}